<!doctype html>
<html>
<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Merall</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' rel='stylesheet'>
    <style>@import url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

        body {
            background-color: #efefef;
            font-family: 'Montserrat', sans-serif;
            margin-bottom: 0px !important;
        }

        .card {
            border: none
        }

        .logo {
            background-color: #dbc9fd;
        }

        .totals tr td {
            font-size: 13px
        }

        .footer {
            background-color: #dbc9fd
        }

        .footer span {
            font-size: 12px
        }

        .product-qty span {
            font-size: 12px;
            color: #dedbdb
        }

    @media print {

        body{
            background: unset !important;
        }
    }
    </style>
    <script type='text/javascript' src=''></script>
    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js'></script>
    <script type='text/javascript'></script>
</head>
<body oncontextmenu='return false' class='snippet-body'>
<div class="container" style="direction: rtl">
    <div class="row d-flex justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="text-left logo p-3 px-10"> <img src="{{asset('assets/web/images/logo.png')}}" width="150"> </div>
                <div class="invoice p-5">
                    <span class="font-weight-bold d-block mt-4"> اسم العميل : {{$order->name}}</span>
                    <div class="payment border-top mt-3 mb-3 border-bottom table-responsive">
                        <table class="table table-borderless">
                            <tbody>
                            <tr>
                                <td>
                                    <div class="py-2"> <span class="d-block text-muted">تاريخ الاوردر</span> <span>{{$order->created_at->format('Y-m-d')}}</span> </div>
                                </td>
                                <td>
                                    <div class="py-2"> <span class="d-block text-muted">رقم الاوردر</span> <span>MR-{{$order->id}}</span> </div>
                                </td>
                                <td>
                                    <div class="py-2"> <span class="d-block text-muted">الدفع</span> <span>{{$order->payment}}</span> </div>
                                </td>
                                <td>
                                    <div class="py-2" style="direction: rtl"> <span class="d-block text-muted">عنوان الشحن</span> <span>{{$order->country->name . " - " . $order->area->name . " - " . $order->address}}</span> </div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="product border-bottom table-responsive">
                        <table class="table table-borderless">
                            <tbody>
                                @foreach($order->orderCarts as $cart)
                                    <tr>
                                        <td width="20%"> <img src="{{asset("assets/web/images/carts/$cart->img")}}" style="max-width: 50px"> </td>
                                        <td width="60%"> <span class="font-weight-bold">{{$cart->name}}</span>
                                            <div class="product-qty"> <span class="d-block text-black-50 font-weight-bold">الكمية:{{$cart->count}}</span></div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="row d-flex justify-content-end">
                        <div class="col-md-5">
                            <table class="table table-borderless">
                                <tbody class="totals">
                                <tr>
                                    <td>
                                        <div class="text-left"> <span class="text-muted">المجموع الفرعي</span> </div>
                                    </td>
                                    <td>
                                        <div class="text-right"> <span>{{$order->price}} ريال</span> </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="text-left"> <span class="text-muted">رسوم الشحن</span> </div>
                                    </td>
                                    <td>
                                        <div class="text-right"> <span>{{$order->shipping_price}}</span> </div>
                                    </td>
                                </tr>
{{--                                <tr>--}}
{{--                                    <td>--}}
{{--                                        <div class="text-left"> <span class="text-muted">Tax Fee</span> </div>--}}
{{--                                    </td>--}}
{{--                                    <td>--}}
{{--                                        <div class="text-right"> <span>$7.65</span> </div>--}}
{{--                                    </td>--}}
{{--                                </tr>--}}
{{--                                <tr>--}}
{{--                                    <td>--}}
{{--                                        <div class="text-left"> <span class="text-muted">Discount</span> </div>--}}
{{--                                    </td>--}}
{{--                                    <td>--}}
{{--                                        <div class="text-right"> <span class="text-success">$168.50</span> </div>--}}
{{--                                    </td>--}}
{{--                                </tr>--}}
                                <tr class="border-top border-bottom">
                                    <td>
                                        <div class="text-left"> <span class="font-weight-bold">الاجمالي</span> </div>
                                    </td>
                                    <td>
                                        <div class="text-right"> <span class="font-weight-bold">$238.50</span> </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <p>{{strlen($order->not) > $order->not ? $order->not : "لاتوجد اي ملاحظات متعلقة بالاوردر او الشحن"}}</p>
                    <p class="font-weight-bold mb-0">شكرا لثقتك بنا</p> <span>فريق ميرال</span>
                </div>
                <div class="d-flex justify-content-between footer p-3"> <span>Meralll.com</span>  <span>055282229</span></div>
            </div>
        </div>
    </div>
</div>

<script !src="">
    window.print()
</script>
</body>
</html>
