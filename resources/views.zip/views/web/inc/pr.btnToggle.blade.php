<div class="pt-btn-toggle">
    <a href="#">
        <span class="pt-icon">
            <svg>
                <use xlink:href="#icon-filter"></use>
            </svg>
        </span>
        <span class="pt-text">
            تصفية
        </span>
    </a>
</div>
