<ul class="pt-add-info">
    @php($cat = $product->cats->first())
    <li class="d-inline-block"><a href="{{route('web.cat.show' , $cat->slug)}}">{{$cat->name}}</a></li>
</ul>
