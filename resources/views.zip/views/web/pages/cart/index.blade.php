@php($title_page      = 'سلة التسوق')
@php($title_seo       = 'سلة التسوق')

@extends('web.master')

@section('breadcrumb')
    <li><a href="{{url('/')}}">الرئيسية</a></li>
    <li>سلة التسوق</li>
@endsection

@section('content')

    @php($authCheck = auth()->check())
    @php($name    = old('name') ? old('name') :( $authCheck ? auth()->user()->name : ''))
    @php($email   = old('email') ? old('email') : ($authCheck ? auth()->user()->email : ''))
    @php($phone   = old('phone') ? old('phone') : ($authCheck ? auth()->user()->phone : ''))
    @php($country_id = old('country') ? old('country') : ($authCheck ? auth()->user()->country_id : 0))
    @php($area_id    = old('area') ? old('area') : ($authCheck ? auth()->user()->area_id : 0))

    @if ($carts->count() > 0)

        <main id="pt-pageContent">
            @if (session()->has('message'))
                <div class="alert alert-success">{{session('message')}}</div>
            @endif
            @if (session()->has('error'))
                <div class="alert alert-danger">{{session('error')}}</div>
            @endif
            <div class="container-indent">
                <div class="container">
                    <h1 class="pt-title-subpages noborder">سلة التسوق</h1>
                    <div class="row">
                        <div class="col-xl-8">
                            <div class="pt-shopcart-page size-small">
                                <form method="post" action="{{route('web.cart.update' , 0)}}" id="form-update-cart">
                                   @csrf
                                    {{method_field('put')}}
                                    @include('web.pages.cart.product')
                                    <div class="pt-shopcart-btn">
                                        <div class="pt-col">
                                            <a href="{{url('/')}}" class="btn-link btn-lg">
                                                <div class="pt-icon">
                                                    <svg width="24" height="24" viewBox="0 0 24 24">
                                                        <use xlink:href="#icon-arrow_large_left"></use>
                                                    </svg>
                                                </div>
                                                <span class="pt-text">العودة الي التسوق</span>
                                            </a>
                                        </div>
                                        <div class="pt-col">
                                            <a href="{{route('web.cart.cart_delete_all')}}" class="btn-link btn-lg">
                                                <div class="pt-icon">
                                                    <svg width="24" height="24" viewBox="0 0 24 24">
                                                        <use xlink:href="#icon-remove"></use>
                                                    </svg>
                                                </div>
                                                <span class="pt-text">حذف كل المنتجات من السلة</span>
                                            </a>
                                            <a href="#" class="btn-link btn-lg" id="btn-update-cart">
                                                <div class="pt-icon">
                                                    <svg width="24" height="24" viewBox="0 0 24 24">
                                                        <use xlink:href="#icon-update"></use>
                                                    </svg>
                                                </div>
                                                <span class="pt-text">تحديث التعديلات في السلة</span>
                                            </a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        @include('web.pages.cart.shipping')
                    </div>
                </div>
            </div>
        </main>
        <form method="post" action="" class="d-none" id="form_delete_product">
            @csrf
            {{method_field('delete')}}
        </form>
    @else
        @include('web.pages.cart.empty')
    @endif
@endsection

@section('js')
    <script>
        $(function () {

            let selectArea = $('#area'),
                areas = [];

            $('#country').on('change', function (e) {

                selectArea_method($(this));
            });

            selectArea_method($('#country'))


            function selectArea_method($this) {

                let data = $.parseJSON($this.find(':selected').attr('data-areas'));

                $.each(data, function ($key, $val) {

                    let $id = $val['id'];
                    let  isSelected = $id == {{$area_id}} ? 'selected' : '';

                    areas.push("<option "+isSelected+" value='" + $id +"' data-shipping='"+$val['shipping_price']+"'>" + $val['name'] + "</option>")

                })

                selectArea.html(areas);
                areas = [];
            }




            $('#cache').on('change' , function (){

                $('#bank-box').slideUp(500);
                $('#cache-box').slideDown(500);
            })

            $('#bank').on('change' , function (){

                $('#bank-box').removeClass('d-none').slideDown(500);
                $('#cache-box').slideUp(500);
            })

            $('#btn-update-cart').on('click' , function (e){

                e.preventDefault();

                $('#form-update-cart').submit()
            })

            $('.js-remove-item').on('click' , function (e){

                e.preventDefault();

                $('#form_delete_product').attr('action' , $(this).attr('data-href')).submit()
            })

            // let orderPrice = $('#order-price span');
            let orderTotal = $('#order-total span');
            let productsTotalPrice = $('.total-price .pt-price');
            let sumPrice = 0

            $('.plus-btn , .minus-btn').on('click' , function (){


                setTimeout( ()=>{

                    let minPrice =  $(this).parents('.pt-col').siblings('.min-price').attr('data-price');
                    let countProducts =  $(this).siblings('.count-products').val();
                    let totalPrice =  $(this).parents('.pt-col').siblings('.total-price').children('.pt-price');

                    totalPrice.text(minPrice*countProducts + ' ريال')

                    // productsTotalPrice.each(function (){
                    //
                    //     sumPrice += parseFloat($(this).text())
                    // })

                    // orderPrice.text(sumPrice)
                    // orderTotal.text(parseFloat($('#area-shipping-price').text())+sumPrice)
                    // sumPrice = 0;
                }  ,250)
            })

            let area_shipping_price = $('#area-shipping-price')
            $('body').on('change' , '#area' , function (){

                area_shipping_price.text($(this).find(':selected').attr('data-shipping'))

                productsTotalPrice.each(function (){
                    sumPrice += parseFloat($(this).text())
                })

                orderTotal.text(sumPrice+parseFloat($(this).find(':selected').attr('data-shipping')))

                sumPrice = 0
            })


            area_shipping_price.text(parseFloat(selectArea.find(':selected').attr('data-shipping')))
            orderTotal.text(parseFloat(orderTotal.text())+parseFloat(selectArea.find(':selected').attr('data-shipping')))


        });




    </script>
@endsection
