<div class="col-md-4 col-lg-3 col-xl-3 leftColumn rightColumn aside">
    <div class="pt-btn-col-close">
        <a href="#">
            <span class="pt-icon">
                <svg>
                    <use xlink:href="#icon-close"></use>
                </svg>
            </span>
            <span class="pt-text">
                اغلاق
            </span>
        </a>
    </div>
    <div class="pt-collapse open pt-filter-detach-option">
        <div class="pt-collapse-content">
            <div class="filters-mobile">
                <div class="filters-row-select">

                </div>
            </div>
        </div>
    </div>
    @include('web.inc.as-orderBy')
    @include('web.inc.as-rangPrice')
    @include('web.inc.as-cats')
    @include('web.inc.as-offer')
</div>
