@php($title_page      = 'الملف الشخصي')
@php($title_seo       = 'الملف الشخصي')

@extends('web.master')

@section('breadcrumb')
    <li><a href="{{url('/')}}">الرئيسية</a></li>
    <li>الملف الشخصي</li>
@endsection
@section('content')
    <div class="container-indent">
        @if (session()->has('message'))
            <div class="alert alert-success">{{session('message')}}</div>
        @endif
        <div class="container">
            <h1 class="pt-title-subpages noborder">الملف الشخصي</h1>
            <div class="pt-account-layout">
                <h2 class="pt-title-page">بيانات الحساب</h2>
                <div class="pt-wrapper">
                    <h3 class="pt-title">سجل الاوردرات</h3>
                    <div class="alert alert-info">يمكنك حذف الاوردرات التي ما زالت في المراجعة فقط</div>

                    <div class="pt-table-responsive">
                        <table class="pt-table-shop-01">
                            <thead>
                            <tr>
                                <th>رقم الاوردر</th>
                                <th>التاريخ</th>
                                <th>حالة الاوردر</th>
                                <th>عدد المنتجات</th>
                                <th>الاجمالي</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($orders->all() as $order)
                                <tr>
                                    <td><a href="{{route('profile.deleteOrder' , $order->id)}}">{{$order->id}}</a></td>
                                    <td>{{$order->created_at->format('Y-m-d')}}</td>
                                    <td>{{$order->orderStatus($order->status)}}</td>
                                    <td>{{$order->product_count}} منتجات</td>
                                    <td>{{$order->total}} ريال سعودي</td>
                                    <td>
                                        <a href="{{route('profile.order.show' , $order->id)}}" class="btn btn-info d-block  text-white text-center mb-2" style="line-height: 35px">عرض جميع التفاصيل</a>
                                        @if ($order->status == "في انتظار المراجعة")
                                            <a href="{{route('profile.deleteOrder' , $order->id)}}" class="btn btn-danger text-white d-block " style="line-height: 35px; background-color: #4b0218">حذف الاوردر</a>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="pt-wrapper">
                    <h3 class="pt-title">البيانات الشخصية</h3>
                    <div class="pt-table-responsive">
                        <table class="pt-table-shop-02">
                            <tbody>
                            <tr>
                                <td>الاسم:</td>
                                <td>{{$user->name}}</td>
                            </tr>
                            <tr>
                                <td>البريد الالكتروني:</td>
                                <td>{{$user->email}}</td>
                            </tr>
                            <tr>
                                <td>رقم الهاتف:</td>
                                <td>{{$user->phone}}</td>
                            </tr>
                            <tr>
                                <td>الدولة:</td>
                                <td>{{$user->country->name}}</td>
                            </tr>
                            <tr>
                                <td>المحافظة:</td>
                                <td>{{$user->area->name}}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <a href="{{route('profile.edit')}}" class="btn btn-border">تعديل البيانات</a>
                </div>
            </div>
        </div>
    </div>

@endsection
