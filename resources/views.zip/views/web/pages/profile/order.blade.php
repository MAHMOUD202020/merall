@extends('web.master')

@section('breadcrumb')
    <li><a href="{{url('/')}}">الرئيسية</a></li>
    <li><a href="{{route('profile.index')}}">الملف الشخصي</a></li>
    <li>تفاصيل الاوردر</li>

@endsection
@section('content')
    <div class="container-indent">
        <div class="container">
            <h1 class="pt-title-subpages noborder">الملف الشخصي</h1>
            <div class="pt-account-layout">
                <h2 class="pt-title-page">تفاصيل الاوردر رقم #{{$order->id}}</h2>
                <div class="pt-wrapper">
                    <a href="{{route('profile.index')}}" class="btn-link btn-lg pt-link-back">
                        <div class="pt-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24">
                                <use xlink:href="#icon-arrow_large_left"></use>
                            </svg>
                        </div>
                        <span class="pt-text">العودة الي الملف الشخصي</span>
                    </a>
                </div>
                <div class="pt-data">التاريخ : {{$order->created_at}}</div>
                <div class="pt-wrapper">
                    <div class="pt-table-responsive">
                        <table class="pt-table-shop-03">
                            <thead>
                            <tr>
                                <th>المنتج</th>
                                <th>السعر</th>
                                <th>الضريبة</th>
                                <th>الكمية</th>
                                <th style="white-space: nowrap">اجمالي السعر</th>
                            </tr>
                            </thead>
                            <tbody>

                            @foreach($order->orderCarts as $product)
                                @php($tax = ($product->price * 15)/100 )
                                <tr>
                                    <td>{{$product->name}}</td>
                                    <td>{{$product->price - $tax}} ريال</td>
                                    <td>{{$tax}} ريال</td>
                                    <td>{{$product->count}} منتج</td>
                                    <td>{{$product->total}} ريال</td>
                                </tr>
                            @endforeach
                            <tr>
                                <td colspan="4"><strong>اجمالي المنتجات</strong></td>
                                <td><strong>{{$order->price}} ريال </strong></td>
                            </tr>
                            <tr>
                                <td colspan="4"><strong>سعر الشحن</strong></td>
                                <td><strong>{{$order->shipping_price}} ريال </strong></td>
                            </tr>
                            <tr>
                                <td colspan="4"><strong>اجمالي الاوردر</strong></td>
                                <td><strong>{{$order->total}} ريال </strong></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="pt-wrapper">

                    <div class="bg-light p-1 pt-title-page">بيانات الشحن</div>
                    <table class="table-shipping pt-table-03">
                        <thead>
                        <tr>
                            <th scope="col">الدولة:</th>
                            <th scope="col">{{$order->country->name}}</th>
                        </tr>
                        <tr>
                            <th scope="col">المحافظة:</th>
                            <th scope="col">{{$order->area->name}}</th>
                        </tr>
                        <tr>
                            <th scope="col">العنوان:</th>
                            <th scope="col">{{$order->address}}</th>
                        </tr>
                        <tr>
                            <th scope="col">رقم الهاتف:</th>
                            <th scope="col">{{$order->phone}}</th>
                        </tr>
                        <tr>
                            <th scope="col">البريد:</th>
                            <th scope="col">{{$order->email}}</th>
                        </tr>

                        </thead>
                        <tbody>
                    </table>
                    <hr>
                    <div class="bg-light p-1 pt-title-page mb-2">تفاصيل اخري</div>
                    <div class="pt-shop-info mb-5">
                        <div class="pt-item">
                            <strong><a>حالة الاوردر: {{$order->orderStatus($order->status)}}</a></strong>
                            <nl class="mt-3 d-block"> </nl>
                            <strong><a>نوع الدفع: {{$order->payment}} </a></strong>
                            @if ($order->img_payment)
                                <nl class="mt-3 d-block"> </nl>
                                <strong>الايصال</strong>
                                <img class="img-fluid img-thumbnail" src="{{asset("assets/web/images/payment/$order->img_payment")}}" alt="">
                            @endif
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

@endsection
@section('css')
    <style>
        .table-shipping th {

            color: white;
            padding: 10px;
        }
        .table-shipping tr:nth-child(odd) {
            background-color: #00968875;
        }
        .table-shipping tr:nth-child(even) {
            background-color: #607d8b;
        }

    </style>
@endsection
