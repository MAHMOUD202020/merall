@php($title_page      = 'الصفحة الرئيسية')
@php($title_seo       = 'الصفحة الرئيسية')

@extends('web.master')

@section('content')

    @include('web.pages.home.slider')
{{--    @include('web.pages.home.banners')--}}
    @include('web.pages.home.new_product')
    @include('web.inc.banners')
    @include('web.pages.home.premium_product')
    <div class="container">
        <div class="row">
            <div class="col-12" style="max-height: 400px">
                <a href="#" class="pt-promo-box">
                    <div class="image-box">
                        <img src="{{asset('assets/web/images/banners/custome.jpg')}}" alt="banner">
                    </div>
                    <div class="pt-description pr-promo-type2 pt-point-h-l">
                    </div>
                </a>
            </div>
        </div>
    </div>

    @include('web.pages.home.Offers_product')

    <div class="container">
        <div class="row">
            <div class="col-12" style="max-height: 400px; overflow: hidden; margin-bottom: 25px">
                <a href="#" class="pt-promo-box">
                    <div class="image-box">
                        <img src="{{asset('assets/web/images/banners/custom2.png')}}" alt="banner">
                    </div>
                    <div class="pt-description pr-promo-type2 pt-point-h-l">
                    </div>
                </a>
            </div>
        </div>
    </div>
@endsection
