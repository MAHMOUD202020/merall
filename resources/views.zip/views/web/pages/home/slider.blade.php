<div class="container-indent nomargin">
    <div class="mainSlider-layout">
        <div class="mainSliderSlick mainSliderSlick-js arrow-slick-main">
            <div class="slide">
                <div class="img--holder">
                    <picture>
                        <source srcset="{{asset('assets/web/images/slider/small_slide1.jpg')}}" media="(max-width: 767px)" type="image/jpg">
                        <source srcset="{{asset('assets/web/images/slider/slide1.png')}}" media="(max-width: 1024px)" type="image/jpg">
                        <source srcset="{{asset('assets/web/images/slider/slide1.png')}}" type="image/jpg">
                        <img src="{{asset('assets/web/images/slider/slide1.png')}}" alt="">
                    </picture>
                </div>
                <div class="slide-content pt-point-h-r">
                    <div class="pt-container" data-animation="fadeInRightSm" data-animation-delay="0s">
                        <div class="tp-caption1-wd-1 pt-white-color"></div>
                        <div class="tp-caption1-wd-2 pt-white-color text-danger">ميرال لأجمل غزال</div>
                        <div class="tp-caption1-wd-3 pt-white-color text-dark">منتجات لأكبر الماركات العالميه المتنوعه من مكياج  و عنايه للجسم والشعر والبشره الموثوق بها</div>
                        <div class="tp-caption1-wd-4"><a href="{{'premium'}}" target="_blank" class="btn" data-text="DISCOVER NOW!">تسوقي الان</a></div>
                    </div>
                </div>
            </div>
            <div class="slide">
                <div class="img--holder">
                    <picture>
                        <source srcset="{{asset('assets/web/images/slider/small_slide2.png')}}" media="(max-width: 767px)" type="image/jpg">
                        <source srcset="{{asset('assets/web/images/slider/slide2.jpg')}}" media="(max-width: 1024px)" type="image/jpg">
                        <source srcset="{{asset('assets/web/images/slider/slide2.jpg')}}" type="image/jpg">
                        <img src="{{asset('assets/web/images/slider/slide2.jpg')}}" alt="">
                    </picture>
                </div>
                <div class="slide-content pt-point-h-l" data-animation="fadeInLeftSm" data-animation-delay="0s">
                    <div class="pt-container">
                        <div class="tp-caption1-wd-2 text-danger">ميرال مآل الجمال</div>
                        <div class="tp-caption1-wd-3 pt-text-color text-white">منتجات اصليه 100%
                            لدينا خبراء تجميل وعنايه لاي استفسار عن منتجاتنا وطريقة استخدامها الصحيحه</div>
                        <div class="tp-caption1-wd-4"><a href="{{'premium'}}" target="_blank" class="btn" data-text="DISCOVER NOW!">تسوقي الان</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
