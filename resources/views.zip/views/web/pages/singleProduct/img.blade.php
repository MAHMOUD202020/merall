<div class="pt-product-single-img no-zoom">
    <div>
        <img class="zoom-product" src='{{asset("assets/web/images/products/min/$product->img")}}' data-zoom-image="{{asset("assets/web/images/products/min/$product->img")}}" alt="">
        <button class="pt-btn-zoom js-btnzoom-slider">
            <svg>
                <use xlink:href="#icon-quick_view"></use>
            </svg>
        </button>
    </div>
</div>
