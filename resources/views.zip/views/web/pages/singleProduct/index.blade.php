@php($product_id      = $product->id)
@php($title_page      = $product->name)
@php($title_seo       = $product->seo_title)
@php($description_seo = $product->meta_description)
@php($keywords_seo    = $product->keyword_tag)
@php($img_seo         = asset("assets/web/images/products/min/medium_$product->img"))

@extends('web.master')

@section('breadcrumb')
    <li><a href="{{url('/')}}">الرئيسية</a></li>
    <li>المنتجات</li>
    <li>{{$product->name}}</li>
@endsection

@section('content')

    <div id="pt-pageContent">
        <div class="container-indent pt-offset-md-productsingle">
            <!-- mobile product slider  -->
            @include('web.pages.singleProduct.galleryMobile')
            <!-- /mobile product slider  -->
            <div class="container container-fluid-mobile">
                <div class="row">
                    <div class="col-6 hidden-xs">
                        @include('web.pages.singleProduct.img')
                        @include('web.pages.singleProduct.gallery')
                    </div>
                        @include('web.pages.singleProduct.info')
                </div>
            </div>
        </div>
        <hr>
        <div class="container-indent">
            <div class="container container-fluid-custom-mobile-padding">
                <div class="pt-block-title">
                    <h4 class="pt-title">منتجات قد تعجبك</h4>
                </div>
                <div class="js-init-carousel js-align-arrow row arrow-location-center-02 pt-layout-product-item">
                    @foreach($moro_products as $product)

                        @php($is_new= $product->created_at->addMonth() >= now())
                        @php($is_discount = $product->discount > 0)
                        @php($is_premium = $product->premium == 1)

                        <div class="col-6 col-md-4 col-lg-3">
                            <div class="pt-product">
                                <div class="pt-image-box">

                                    @include('web.inc.pr-btn-app')
                                    @include('web.inc.pr-img')
                                    @include('web.inc.pr-label')
                                </div>
                                <div class="pt-description">
                                    <div class="pt-col">
                                        @include('web.inc.pr-cat')
                                        @include('web.inc.pr-name')
                                    </div>
                                    @include('web.inc.pr-price')
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
@include('web.pages.singleProduct.modelAddCart_singlePage')
@endsection

@section('css')
    <style>

        .btn-like.active .pt-icon{
            color: #dc3545;
        }
    </style>
@endsection
@section('js')
    <script>

        $('.product-color-img').on('click' , function (){

            $('.zoom-product').attr('src' , $(this).attr('data-color-image'))
        })

        let
            coverCart = $('.render-cart'),
            cartProductsCount = $('.cart_products_count');

        $('.btn.btn-lg').on('click' , function (e){

            e.preventDefault();

            $.ajax({
                url:$(this).attr('href'),
                method:'post',
                type:'html',
                data:{'color_id' : undefined , 'quantity': $('#quantity-products').val()},
                success(response){

                    coverCart.html(response.data)

                    cartProductsCount.text(response.count)
                },
            })



            $('#modalAddToCart_singlePage').modal('toggle');
        })

        $('.btn-like').on('click' ,  function (e){

            e.preventDefault();

            $(this).toggleClass('active');

            if ($(this).hasClass('active')){

                $(this).children('.pt-text').text('ازالة من المفضلة')

            }else{

                $(this).children('.pt-text').text('اضافة الي المفضلة')

            }


            $.ajax({

                'url':$(this).attr('href'),

                method:'post',

                success(response){

                    $('#likes-count').text(response.count)
                },
            })

        })

    </script>
@endsection
