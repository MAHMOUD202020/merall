<a href="#" id="js-back-to-top" class="pt-back-to-top">
	<span class="pt-icon">
		<svg version="1.1" x="0px" y="0px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve"><g><polygon fill="currentColor" points="20.9,17.1 12.5,8.6 4.1,17.1 2.9,15.9 12.5,6.4 22.1,15.9 	"></polygon></g></svg>
	</span>
    <span class="pt-text">العودة الي الاعلي</span>
</a>

<a href="https://api.whatsapp.com/send?phone=966504471327&amp;text=some%20predefined%20message&amp;source=&amp;data=" class="btn btn-success btn-rounded btn-whatsapp">تواصلي معنا للاستشارة المجانية</a>

@include('web.layouts.js_slick')

<!-- modal "Add To Cart" -->
{{--<!-- modal "Discount" -->--}}
{{--<div class="modal fade" id="ModalDiscount" tabindex="-1" role="dialog" data-srcvalue="{{asset('assets/web/ajax-content/ajax_modal-discount.html')}}" aria-label="myModalLabel" aria-hidden="true" data-pause=2000 data-localStorage=showedmodal>--}}
{{--    <div class="modal-dialog modal-md"></div>--}}
{{--</div>--}}
