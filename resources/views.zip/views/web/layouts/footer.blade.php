<footer id="pt-footer" class="pt-offset-10">
    <div class="container-indent">
        <div class="container container-fluid-custom-mobile-padding">
            <div class="row pt-services-listing">
                <div class="col-xs-12 col-md-6 col-lg-4">
                    <a class="pt-services-block" target="_blank">
                        <h4 class="pt-title">
							<span class="pt-icon">
								<svg>
									<use xlink:href="#icon-services_delivery"></use>
								</svg>
							</span>
                            <span class="pt-text">التوصيل</span>
                        </h4>
                        <p>شحن مجاني للطلبات التي تزيد عن 250 ريال</p>
                    </a>
                </div>
                <div class="col-xs-12 col-md-6 col-lg-4">
                    <a class="pt-services-block" target="_blank">
                        <h4 class="pt-title">
							<span class="pt-icon">
								<svg>
									<use xlink:href="#icon-services_support"></use>
								</svg>
							</span>
                            <span class="pt-text">دعم 24/7</span>
                        </h4>
                        <p>اتصل بنا 24  ساعة في اليوم ، 7 أيام في الأسبوع.</p>
                    </a>
                </div>
                <div class="col-xs-12 col-md-6 col-lg-4">
                    <a  class="pt-services-block" target="_blank">
                        <h4 class="pt-title">
							<span class="pt-icon">
								<svg>
									<use xlink:href="#icon-services_return"></use>
								</svg>
							</span>
                            <span class="pt-text">إرجاع</span>
                        </h4>
                        <p>ما عليك سوى إعادته في غضون 14 يومًا للاستبدال.</p>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="pt-footer-custom">
        <div class="container">
            <div class="row">

                <div class="col-12 col-md-2 col-lg-3 text-center"></div>
                <div class="col-12 col-md-8 col-lg-6 text-center">
                    <img src="{{asset('assets/web/images/logo.png')}}" alt="merall">
                </div>
                <div class="col-12  text-center">
                    <img src="{{asset('assets/web/images/maroof.png')}}" alt="merall">
                </div>
                <div class="col-12 col-md-2 col-lg-3 text-center"></div>
                <div class="col-12">
                    <!-- copyright -->
                    <div class="pt-box-copyright text-center">
                        &copy; 2020 متجر ميرال . جميع الحقوق محفوظة <a href="https://raya-adv.com/" target="_blank">Raya Adv</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</footer>
