<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\myDataTable\methodAction;
use Illuminate\Http\Request;

class OrderController extends Controller
{

    use methodAction;

    public function index()
    {

        return myDataTable_query(
            Order::class ,
            'admin.pages.order.index');
    }


    public function create()
    {


    }


    public function store(Request $request)
    {




    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order =  Order::where('id' , $id)->firstOrFail();

        return view('admin.pages.order.show' , compact('order'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        $order->update([
            'status'  => $request->status,
            'product_count'  => $request->product_count,
            'price'   => $request->price,
            'shipping_price'  => $request->shipping_price,
            'total'  => $request->total ,
        ]);
        return response(['status' => 'success' , 'message' => 'تم تعديل الاوردر بنجاح']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->MDT_delete(Order::class , $id);
    }

}
