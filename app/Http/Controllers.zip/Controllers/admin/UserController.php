<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\Models\Country;
use App\Models\User;
use App\myDataTable\methodAction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

class UserController extends Controller
{

    use methodAction;
    protected $path = ['0' => 'admin.pages.user' , '1' => 'admin.pages.admin'];

    public function index()
    {
        $admin = Route::currentRouteName() === "admin.user.index" ? 0 : 1;

        return myDataTable_query(
            User::class ,
            $this->path[$admin].'.index' ,
        false ,
        [
            'typeWhere' =>  ['where' , 'admin' , '=' , $admin],
        ]);
    }


    public function create()
    {

        $admin = Route::currentRouteName() === "admin.user.index" ? 0 : 1;

        $countries  = Country::with('areas')->get(['name' , 'id']);

        return  view($this->path[$admin].'.create')->with('countries' , $countries);
    }


    public function store(UserRequest $request)
    {
        $admin = Route::currentRouteName() === "admin.user.store" ? 0 : 1;

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'admin' => $admin,
            'country_id' => $request->country,
            'area_id' => $request->area,
            'password' => bcrypt($request->password),
        ]);



        return  back()->with('success' , 'تم اضافة المستخدم بنجاح');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, $id)
    {

        $user = User::withTrashed()->findOrFail($id);

        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            $request->has('password') ? 'password' : '' => encrypt($request->password),
        ]);

        return response(['status' => 'success' , 'message' => 'تم تعديل المستخدم بنجاح']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->MDT_delete(User::class , $id);
    }

    public function trash()
    {
        $admin = Route::currentRouteName() === "admin.user.trash" ? 0 : 1;

        return myDataTable_query(
            User::class ,
            $this->path[$admin].'.trash' ,
            true ,
            [
                'typeWhere' =>  ['where' , 'admin' , '=' , $admin]
            ]);

    }

    public function restore($id)
    {

        return $this->MDT_restore(User::class , $id);
    }

    public function finalDelete($id)
    {
        return $this->MDT_finalDelete(User::class , $id);
    }
}
