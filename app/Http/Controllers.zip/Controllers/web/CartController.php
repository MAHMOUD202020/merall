<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Country;
use App\Models\Product;
use Illuminate\Http\Request;
use function GuzzleHttp\Promise\all;

class CartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function start(){

        $carts = auth()->check()
            ?  Cart::doesntHave('orderCart')->where('user_id' , auth()->id())->latest('id')->get()
            : Cart::doesntHave('orderCart')->where('guest_ip' , request()->ip())->latest('id')->get();


        $newCart = view('web.pages.cart.render')->with('carts'  , $carts)->render();

        return response(['status' => 'success' , 'data' => $newCart , 'count' => $carts->count()]);

    }

    public function index()
    {
        $countries  = Country::with('areas')->get(['name' , 'id']);
        $carts = auth()->check()
            ?  Cart::doesntHave('orderCart')->where('user_id' , auth()->id())->latest('id')->get()
            : Cart::doesntHave('orderCart')->where('guest_ip' , request()->ip())->latest('id')->get();

        return  view('web.pages.cart.index')->with(['countries' => $countries , 'carts' => $carts]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function store(Request $request){


        $product = Product::findOrFail($request->product);

        $color = null;

        if ($request->color_id) {

            $color   = $product->colors()->where('color_id' , $request->color_id)->first();
            abort(404);
        }

        if (auth()->check()) {


            $this->add_to_cart_is_auth($product , $color);

        }else {


            $this->add_to_cart_is_guest($product , $color);
        }

        $carts = auth()->check()
            ?  Cart::where('user_id' , auth()->id())->latest('id')->get()
            : Cart::where('guest_ip' , request()->ip())->latest('id')->get();


        $newCart = view('web.pages.cart.render')->with('carts'  , $carts)->render();

        return response(['status' => 'success' , 'data' => $newCart , 'count' => $carts->count()]);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }


    public function update(Request $request, $id)
    {

        foreach ($request->card as $card){

            $newQu = (int)$card['quantity'] > 0  ? (int)$card['quantity'] : 1;

            auth()->check()
                ? Cart::where('id' , (int)$card['id'])
                ->where('user_id' , auth()->id())
                ->update([

                    'quantity' => $newQu

                 ])

                :Cart::where('id' , (int)$card['id'])
                ->where('guest_ip' , $request->ip())
                ->update([

                    'quantity' => $newQu

                 ]);
        }

        return back()->with('message' , 'تم تحديث السلة');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        auth()->check()
            ? Cart::doesntHave('orderCart')->where('id' , $id)->where( 'user_id' , auth()->id())->delete()
            : Cart::doesntHave('orderCart')->where('id' , $id)->where( 'guest_ip' , \request()->ip())->delete();


        if (\request()->ajax()) {

            return  response(['status' => 'success']);
        }

        return back()->with('message' , 'تم حذف المنتج من السلة');
    }


    public function cart_delete_all(){

        auth()->check()
            ? Cart::where( 'user_id' , auth()->id())->delete()
            : Cart::where( 'guest_ip' , \request()->ip())->delete();

        return back();
    }

    private function add_to_cart_is_auth($product , $color){

        $endPrice = $product->discount > 0 ? $product->discount : $product->price ;

        $oldCart = auth()->user()->carts->where('product_id' , $product->id)->first();

        if ($oldCart) {

            $endQuantity = $oldCart->quantity+1;

            $oldCart->update([

                'name' => $product->name,
                'quantity' => $endQuantity,
                'img' => $product->img,
                'slug' => $product->slug,
                'min_price' => $endPrice,
                'price' => $endPrice * $endQuantity,
                'color_name' => $color ? $color->name : null,
                'color_img' => $color ? $color->img : null,

            ]);

        }else{

            auth()->user()->carts()->create([

                'name' => $product->name,
                'quantity' => 1,
                'img' => $product->img,
                'slug' => $product->slug,
                'min_price' => $endPrice,
                'price' => $endPrice,
                'color_name' => $color ? $color->name : null,
                'color_img' => $color ? $color->img : null,
                'product_id' => $product->id,
            ]);

        }
    }
    private function add_to_cart_is_guest($product , $color){

        $endPrice = $product->discount > 0 ? $product->discount : $product->price ;

        $ip = \request()->ip();


        $oldCart = Cart::where('product_id' , $product->id)
            ->where('guest_ip' , $ip)->first();

        if ($oldCart) {

            $endQuantity = $oldCart->quantity+1;

            $oldCart->update([
                'name' => $product->name,
                'quantity' => $endQuantity,
                'img' => $product->img,
                'slug' => $product->slug,
                'min_price' => $endPrice,
                'price' => $endPrice * $endQuantity,
                'color_name' => $color ? $color->name : null,
                'color_img' => $color ? $color->img : null,
            ]);

        }
        else{

            Cart::create([

                'name' => $product->name,
                'quantity' => 1,
                'img' => $product->img,
                'slug' => $product->slug,
                'min_price' => $endPrice,
                'price' => $endPrice,
                'color_name' => $color ? $color->name : null,
                'color_img' => $color ? $color->img : null,
                'product_id' => $product->id,
                'guest_ip' => $ip,
            ]);
        }
    }
}
