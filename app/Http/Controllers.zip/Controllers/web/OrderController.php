<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Controller;
use App\Http\Requests\CartRequest;
use App\Models\Area;
use App\Models\Cart;
use App\Models\Country;
use App\Models\Order;
use App\Models\OrderCart;
use App\Models\Product;
use App\Models\Profile;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $countries  = Country::with('areas')->get(['name' , 'id']);

        return  view('web.pages.cart.index')->with('countries' , $countries);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    public function store(CartRequest $request){


        $country = Country::findOrFail($request->country);
        $area    = Area::where('id' , $request->area)->where('country_id' , $country->id)->firstOrFail();

        if (!auth()->check()) {


            $user = User::create([
                'name' => $request->get('name'),
                'email' => $request->get('email'),
                'phone' => $request->get('phone'),
                'country_id' => $request->get('country'),
                'area_id' => $request->get('area'),
                'password' => Hash::make($request->get('password')),
            ]);


            Auth::attempt( ['email' => $request->email , 'password' => $request->password] , true);

            Cart::where('guest_ip' , $request->ip())->update([

                'guest_ip' => null,
                'user_id' => $user->id
            ]);

        }else{

            $user = \auth()->user();
        }


        $carts = $user->carts()->get();

        if ($carts->count() <=0 ) {

            return redirect()->back();
        }

        $product_count = $carts->map->quantity->sum();
        $product_price = $carts->map->price->sum();

        $img_name = null;
        if($request->has('img_payment')){

            $img = $request->file('img_payment');
            $img_name = rand(100000, 8000000).'.jpg';
            $img->move(public_path('assets/web/images/payment/') , $img_name);
        }

        $order = Order::create([

            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone' =>$request->get('phone') ,
            'not' => $request->get('not'),
            'address' => $request->get('address'),
            'shipping_price' => $area->shipping_price,
            'product_count' => $product_count,
            'payment' => $request->get('payment'),
            'img_payment' => $img_name,
            'price' => $product_price,
            'total' => $product_price + $area->shipping_price,
            'user_id' =>$user->id,
            'country_id' => $country->id,
            'area_id' => $area->id,

        ]);

        $orderCartData = [];
        $i= 0;

        foreach ($carts as $cart){

            $orderCartData[$i]['name'] = $cart->name;
            $orderCartData[$i]['count'] = $cart->quantity;
            $orderCartData[$i]['price'] = $cart->min_price;
            $orderCartData[$i]['total'] = $cart->price;
            $orderCartData[$i]['order_id'] = $order->id;
            $orderCartData[$i]['cart_id'] = $cart->id;
            $i++;
        }

        OrderCart::insert($orderCartData);

        return redirect("profile/show/order/$order->id")->with('message' , 'تم تسجيل الاودر بنجاح');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        auth()->check()
            ? Cart::where('id' , $id)->where( 'user_id' , auth()->id())->delete()
            : Cart::where('id' , $id)->where( 'guest_ip' , \request()->ip())->delete();


        return  response(['status' => 'success']);
    }

    private function add_to_cart_is_auth($product){

        $endPrice = $product->discount > 0 ? $product->discount : $product->price ;

        $oldCart = auth()->user()->carts->where('product_id' , $product->id)->first();

        if ($oldCart) {

            $endQuantity = $oldCart->quantity+1;

            $oldCart->update([

                'quantity' => $endQuantity,
                'price' => $endPrice * $endQuantity
            ]);

        }else{

            auth()->user()->carts()->create([

                'name' => $product->name,
                'quantity' => 1,
                'img' => $product->img,
                'price' => $endPrice,
                'product_id' => $product->id,
            ]);

        }
    }
    private function add_to_cart_is_guest($product){

        $endPrice = $product->discount > 0 ? $product->discount : $product->price ;

        $ip = \request()->ip();


        $oldCart = Cart::where('product_id' , $product->id)
            ->where('guest_ip' , $ip)->first();

        if ($oldCart) {

            $endQuantity = $oldCart->quantity+1;

            $oldCart->update([

                'quantity' => $endQuantity,
                'price' => $endPrice * $endQuantity
            ]);

        }
        else{

            Cart::create([

                'name' => $product->name,
                'quantity' => 1,
                'img' => $product->img,
                'price' => $endPrice,
                'product_id' => $product->id,
                'guest_ip' => $ip,
            ]);
        }
    }
}
